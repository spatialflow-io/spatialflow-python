# MethodEnum

HTTP methods for webhooks

## Enum

* `POST` (value: `'POST'`)

* `PUT` (value: `'PUT'`)

* `PATCH` (value: `'PATCH'`)

* `GET` (value: `'GET'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


