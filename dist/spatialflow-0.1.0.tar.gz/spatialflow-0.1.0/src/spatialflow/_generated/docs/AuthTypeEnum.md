# AuthTypeEnum

Webhook authentication types

## Enum

* `NONE` (value: `'none'`)

* `BEARER` (value: `'bearer'`)

* `BASIC` (value: `'basic'`)

* `API_KEY` (value: `'api_key'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


