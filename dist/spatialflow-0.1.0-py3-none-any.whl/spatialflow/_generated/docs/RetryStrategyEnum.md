# RetryStrategyEnum


## Enum

* `EXPONENTIAL_BACKOFF` (value: `'exponential_backoff'`)

* `LINEAR_BACKOFF` (value: `'linear_backoff'`)

* `FIXED_DELAY` (value: `'fixed_delay'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


